const questionsToAsk = [
    {

        question: "What is a dog?",
        answerCorrect: "An animal",
        answerWrong1: "Your accountant",
        answerWrong2: "A six pack of pens",
        answerWrong3: "A box of chocolates"
    },
    {
        question: "What is JavaScript?",
        answerWrong1: "A type of bread",
        answerWrong2: "A dangerous explosive",
        answerCorrect: "JavaScript is a scripting language that enables you to create dynamically updating content",
        answerWrong3: "a place or club where you can go to exercise using machines, weights, and other equipment"
    }

];
console.log(questionsToAsk);