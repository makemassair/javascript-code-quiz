

// hide the introduction
// click.start which hides id=start-screen and reveals id=questions
var beginQuiz = document.querySelector(".start");
console.log(beginQuiz);