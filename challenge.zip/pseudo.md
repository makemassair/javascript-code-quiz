# JavaScript Quiz Game

## List of requirements

* Questions
    * Multiple choice options

* Logic list
// handler for the start button
    // initialise the game
    // start the timer
    // hide the introduction
    // display first question

// if answer = correct then display 'correct' message
    // record that the question was answered correctly
    // display next question

// if answer != correct display 'wrong' message
    // record that the question was answered incorrectly
    // deduct time from timer
    // display next question

// end quiz criteria
    // all questions answered
    // OR when time is left is reduced to < 0 due to incorrect answer
    // OR timer reaches 0

// when quiz ends
    // hide questions
    // display game-end message
    // display user's score
    // option to save score with initial.

// option to restart quiz

// high score page
// read all saved scores
// option to clear all scores

